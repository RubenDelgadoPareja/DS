package factoriaabstracta_metodofactoria;

import java.util.ArrayList;

public class CarreraMontana extends Carrera {
    
    public CarreraMontana(ArrayList<Bicicleta> bicis_carrera){
        super(bicis_carrera);
    }
    
}
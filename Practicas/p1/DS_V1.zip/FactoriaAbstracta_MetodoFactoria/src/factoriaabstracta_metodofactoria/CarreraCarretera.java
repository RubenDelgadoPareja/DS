package factoriaabstracta_metodofactoria;

import java.util.ArrayList;

public class CarreraCarretera extends Carrera {
        
        public CarreraCarretera(ArrayList<Bicicleta> bicis_carrera){
            super(bicis_carrera);
        }
        
}
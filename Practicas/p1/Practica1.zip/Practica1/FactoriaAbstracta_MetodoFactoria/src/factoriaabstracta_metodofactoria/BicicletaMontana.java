package factoriaabstracta_metodofactoria;
public class BicicletaMontana extends Bicicleta {
}
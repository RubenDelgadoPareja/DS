package factoriaabstracta_metodofactoria;
public class Cliente extends Bicicleta {
}
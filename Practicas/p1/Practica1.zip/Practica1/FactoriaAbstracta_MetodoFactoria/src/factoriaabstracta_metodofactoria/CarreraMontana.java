package factoriaabstracta_metodofactoria;
public class CarreraMontana extends Carrera {
}
package factoriaabstracta_metodofactoria;
public class FactoriaCarretera extends FactoriaCarrera_Bicicleta {

	public void crearCarrera() {
		throw new UnsupportedOperationException();
	}

	public void crearBicicleta() {
		throw new UnsupportedOperationException();
	}
}
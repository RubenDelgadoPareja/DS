package factoriaabstracta_metodofactoria;
public class CarreraCarretera extends Carrera {
}
package factoriaabstracta_metodofactoria;
public class BicicletaCarretera extends Bicicleta {
}
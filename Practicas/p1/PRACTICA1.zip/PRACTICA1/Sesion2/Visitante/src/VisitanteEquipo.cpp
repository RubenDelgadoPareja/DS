#include <exception>
using namespace std;

#include "VisitanteEquipo.h"

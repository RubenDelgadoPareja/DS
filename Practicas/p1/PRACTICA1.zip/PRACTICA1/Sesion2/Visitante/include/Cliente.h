/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Cliente.h
 * Author: ruben
 *
 * Created on 7 de marzo de 2020, 15:19
 */

#ifndef CLIENTE_H
#define CLIENTE_H

class Cliente {
public:
    Cliente();
    float getDescuento();
protected:
    float descuento;

};

#endif /* CLIENTE_H */


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s4;

/**
 *
 * @author agus
 */
public class Salpicadero {
    static final double radio = 0.15;
    
    private double rpm;
    private double velocidadLineal;
    private double velocidadAngular;
    private double distanciaRecorrida;
    private double contador_reciente;
    private double contador_total;
    
    
    Salpicadero(){
        this.contador_reciente = 0.0;
        this.contador_total = 0.0;
    }
    
    public void ejecutar(double revoluciones, EstadoMotor estadoMotor){
        if(estadoMotor == EstadoMotor.ACELERANDO || estadoMotor == EstadoMotor.FRENANDO){
            contador_reciente = contador_total;
            contador_total += 0.5;
            this.velocidadLineal = 2*Math.PI*radio*rpm*(60.0/1000.0);
            //Velocidad angular que no tengo ni zorra de como hacerla
            this.velocidadAngular = 0; //????????
            rpm = revoluciones; 
            this.distanciaRecorrida = velocidadLineal; //* tiempo_transcurrido que no se como pollas ponerloooooooo
        }
        
        //Hay que poner algo que calcule el tiempo que transcurre para calcular distanciaRecorrida 
        //Ponemos caso de que se mantenga el vehiculo a cierta velocidad? Pa aumentar cuentaKilometors y eso
    }

    public double getRpm() {
        return rpm;
    }

    public double getVelocidadLineal() {
        return velocidadLineal;
    }

    public double getVelocidadAngular() {
        return velocidadAngular;
    }

    public double getDistanciaRecorrida() {
        return distanciaRecorrida;
    }

    public double getContador_reciente() {
        return contador_reciente;
    }

    public double getContador_total() {
        return contador_total;
    }
    
    
    
}

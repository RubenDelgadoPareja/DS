/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factoriaabstracta_metodofactoria;

import java.util.Scanner;

/**
 *
 * @author agus
 */
public class FactoriaAbstracta_MetodoFactoria {
    static Cliente c = new Cliente();
    static int N;
    
    public static void crearCarreras(){
        int n=0;
        System.out.println("Introduzca el numero de participantes: ");
        Scanner reader = new Scanner(System.in);
        n = reader.nextInt();
        N = n;
        //Creamos primero la carrera de montaña
        c.num_participantes = N;
        FactoriaMontana fm = new FactoriaMontana();
        c.carreras.add(fm.crearCarrera(c.num_participantes));
        
        for(int i=0; i<c.num_participantes; i++)
            c.carreras.get(0).bicicletas.add(fm.crearBicicleta(i));
        //Eliminamos el 20% de las bicicletas totales
        int n1 = (int)(c.num_participantes*0.2);
        int j=0; 
        while(j != n1){
            c.carreras.get(0).bicicletas.remove(c.num_participantes-1);
            c.num_participantes--;
            j++;
        }
        System.out.println("En la carrera de montaña hay " + c.num_participantes + " participantes.");
        c.carreras.get(0).setN(c.num_participantes);
        
        
        //Creamos ahora la carrera de carretera
        c.num_participantes = N;
        FactoriaCarretera fc = new FactoriaCarretera();
        c.carreras.add(fc.crearCarrera(c.num_participantes));
        for(int i=0; i<c.num_participantes; i++)
            c.carreras.get(1).bicicletas.add(fc.crearBicicleta(i));
        //Eliminamos el 10% de las bicicletas totales
        int n2 = (int)(c.num_participantes*0.1);
        int k=0; 
        while(k != n2){
            c.carreras.get(1).bicicletas.remove(c.num_participantes-1);
            c.num_participantes--;
            k++;
        }
        System.out.println("En la carrera de carretera hay " + c.num_participantes + " participantes.");
        c.carreras.get(1).setN(c.num_participantes);
    }
    
    public static void simularCarrera(){
        crearCarreras();
        ((Thread)c.carreras.get(0)).start();
        ((Thread)c.carreras.get(1)).start();
        
        try{
            Thread.sleep(200);
        }catch(Exception MequieroMORIR){
            System.out.println(MequieroMORIR);
        }
    }
    
    public static void main(String[] args) {
        simularCarrera();
        System.out.println("Resultado carrera 1");
        c.carreras.get(0).mostrarRanking();
        System.out.println("Resultado carrera 2");
        c.carreras.get(1).mostrarRanking();
        
    }
    
}

package factoriaabstracta_metodofactoria;
import java.util.Scanner;
import java.util.ArrayList;

public class Cliente{
    public ArrayList<Carrera> carreras = new ArrayList<Carrera>();
    public int num_participantes;
    
    public void getNumParticipantes(){
        
    }
    
}
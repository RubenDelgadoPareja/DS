package factoriaabstracta_metodofactoria;

import java.util.ArrayList;
import java.util.Collections;

public class CarreraMontana extends Carrera {
    
    public CarreraMontana(int i){
        super(i);
    }
    
    public void mostrarRanking(){
        Collections.shuffle(bicicletas);
        String res = "";
        int i=0;
        while(i<8){
            res += bicicletas.get(i).getId() + ",";
            i++;
        }
        System.out.println(res);
    }
    
    
    
}
package factoriaabstracta_metodofactoria;
public abstract class FactoriaCarrera_Bicicleta {
	public abstract Carrera crearCarrera(int n_bici);
            
	public abstract Bicicleta crearBicicleta(int id);
}
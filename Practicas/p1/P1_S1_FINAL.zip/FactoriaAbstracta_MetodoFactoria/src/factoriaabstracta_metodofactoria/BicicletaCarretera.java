package factoriaabstracta_metodofactoria;
public class BicicletaCarretera extends Bicicleta {
    
    public BicicletaCarretera(int id){
        super(id);
    }
    
}
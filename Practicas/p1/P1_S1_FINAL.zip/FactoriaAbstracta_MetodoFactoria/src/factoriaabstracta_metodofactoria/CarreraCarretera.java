package factoriaabstracta_metodofactoria;

import static factoriaabstracta_metodofactoria.FactoriaAbstracta_MetodoFactoria.c;
import java.util.ArrayList;
import java.util.Collections;


public class CarreraCarretera extends Carrera {

        public CarreraCarretera(int bici){
            super(bici);
        }
        
        public void mostrarRanking(){
        Collections.shuffle(bicicletas);
        String res = "";
        int i=0;
        while(i<this.getNumBicicletas()){
            res += bicicletas.get(i).getId() + ",";
            i++;
        }
        System.out.println(res);
        
    }
}